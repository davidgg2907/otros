@extends('layouts.app')

@section('content')

<section>
  <form class="needs-validation" novalidate action="" id="formValidation" method="get" enctype="multipart/form-data">
    <div class="row">

      <div class="col-sm-12">
    		<div class="card">
            <div class="card-header">
                <h4 class="card-title">Agregar factura</h4>
            </div>
            <div class="card-body">
              <div class="row"> 

                <div class="col-md-6">
                  <div class="mb-1">
                    <div class="form-group">
                    <label for="id" class="control-label"> Proveedor/Emisor </label>
                    <select class="form-control" name="emisor" id="emisor">
                      <option value="">[ SELECCIONE ] </option>
                      @foreach(\App\admin\Factura::select('emisor')->groupBy('emisor')->get() as $value)
                        <option value="{{ $value->emisor }}"> {{ $value->emisor }} </option>
                      @endforeach
                    </select>
                    </div>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="mb-1">
                    <div class="form-group">
                    <label for="id" class="control-label"> Receptor </label>
                    <select class="form-control" name="receptor" id="receptor">
                      <option value="">[ SELECCIONE ] </option>
                      @foreach(\App\admin\Factura::select('receptor')->groupBy('receptor')->get() as $value)
                        <option value="{{ $value->receptor }}"> {{ $value->receptor }} </option>
                      @endforeach
                    </select>
                    <div class="label label-danger">{{ $errors->first("id") }}</div>
                    </div>
                  </div>
                </div>


                <div class="col-md-4">
                  <div class="mb-1">
                    <div class="form-group">
                    <label for="id" class="control-label"> Uso de CFDI </label>
                    <select class="form-control" name="usoCFDI" id="usoCFDI">
                      <option value="">[ SELECCIONE ] </option>
                      @foreach(\App\admin\Factura::select('usoCFDI')->groupBy('usoCFDI')->get() as $value)
                        <option value="{{ $value->usoCFDI }}"> {{ $value->usoCFDI }} </option>
                      @endforeach
                    </select>
                    <div class="label label-danger">{{ $errors->first("id") }}</div>
                    </div>
                  </div>
                </div>
              
                <div class="col-md-4">
                  <div class="mb-1">
                    <div class="form-group">
                    <label for="id" class="control-label"> Fecha Emision </label>
                    <input type="text" class="form-control datetime" name="fecha" id="fecha" />
                    <div class="label label-danger">{{ $errors->first("id") }}</div>
                    </div>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="mb-1">
                    <div class="form-group">
                    <label for="id" class="control-label"> UUID </label>
                    <input type="text" class="form-control" name="uuid" id="uuid" />
                    <div class="label label-danger">{{ $errors->first("id") }}</div>
                    </div>
                  </div>
                </div>

                <input type="hidden" class="form-control" name="sending" id="sending" value="1" />
              
              </div>
    				</div>
            <div class="card-footer">
              <div class="row">
                
                <div class="col-md-6" style="text-align:left">
                  <a href="{{ url('admin/factura/descargas') }}" class="btn btn-relief-warning mb-75 waves-effect"><i class="fa-solid fa-eraser"></i> Limpiar </a>                
                </div>
                <div class="col-md-6" style="text-align:right">
                <button type="submit" class="btn btn-relief-primary mb-75 waves-effect"><i class="fa fa-line-chart fa-lg"></i> Generar </button>
                </div>
            
            </div>
            </div>
      		</div>
      </div>

      <div class="col-sm-12">
    		<div class="card">
            <div class="card-header">
                <h4 class="card-title">Resultados</h4>
            </div>
            <div class="card-body">
              <div class="row table-responsive"> 
                  <table class="table" id="example">
                    <thead>
                        <tr>
                            <th class="py-1">Emisor</th>
                            <th class="py-1">Lugar y Fecha</th>
                            <th class="py-1">Receptor</th>
                            <th class="py-1">Metodo Pago</th>
                            <th class="py-1">Serie CSD </th>
                            <th class="py-1">Folio </th>
                            <th class="py-1">No Certificado </th>
                            <th class="py-1">F. Fiscal </th>
                            <th class="py-1">Subtotal </th>
                            <th class="py-1">IVA </th>
                            <th class="py-1">Total </th> 
                        </tr>
                    </thead>
                    <tbody>
                      <?php foreach($data as $value) { ?>
                        <tr>
                            <td>{{ $value->emisor }} </td>
                            <td>{{ $value->lugarExpedicion }} {{ $value->fechaTimbrado }}</td>
                            <td>{{ $value->receptor }}</thtd>
                            <td>{{ $value->metodoPago }}</td>
                            <td>{{ $value->serie }}</td>
                            <td>{{ $value->folio }}</td>
                            <td>{{ $value->noCertificado }}</td>
                            <td>{{ $value->UUID }}</td>
                            <td>{{ number_format($value->subTotal,2,".",",") }}</td>
                            <td>{{ number_format($value->iva,2,".",",") }}</td>                            
                            <td>{{ number_format($value->total,2,".",",") }}</td> 
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
              </div>
    				</div>            
            </div>
      		</div>
      </div>

    </div>
  </form>

</section>

@endsection

@section('scripts')
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>



<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.4.1/css/buttons.dataTables.min.css">
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.4.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.4.1/js/buttons.flash.min.js"></script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.4.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.4.1/js/buttons.print.min.js"></script>




<script>
   $('#example').DataTable( {
    dom: 'Bfrtip',
    buttons: [
      'copyHtml5', 'excelHtml5', 'pdfHtml5', 'csvHtml5'
    ]
} );

</script>

@endsection