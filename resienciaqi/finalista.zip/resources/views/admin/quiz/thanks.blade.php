@extends('layouts.quiz')

@section('content')

<div class="row">

</div>


<section id="extended">
  <div class="row">
      <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
          <h1 style="text-align:center;">Su evaluacion ha sido procesada exitosamente</h1>
          <img class="img-fluid" src="http://localhost/resienciaqi/public//images/pages/login-v2.svg" alt="Login V2">
          <p><br/></p>
          <h3 style="text-align:center;">Gracias por participar</h3>
        </div>
        <div class="col-md-3"></div>
      </div>

  </div>
</section>




@endsection
