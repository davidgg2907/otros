<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-start d-block d-md-inline-block mt-25"> <strong>INSTITUTO QI</strong> &copy; {{ date('Y') }}
      <span class="d-none d-sm-inline-block">, Todos los derechos Reservados</span></span>
      <span class="float-md-end d-none d-md-block">ISC DGG, Hecho con <i data-feather="heart"></i></span></p>
</footer>
<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
